# Safe, Fictional Phishing Awareness Examples

These examples are for classroom discussion only. They contain no active links, real brands, real personal data, or attachments.

## Example 1: Urgent account warning
**Subject:** URGENT: Student account will be deleted

> Hello student, confirm your password immediately or lose access.

**Warning signs:** Threat, urgency, generic greeting, request for a password.

## Example 2: Unexpected prize
**Subject:** You won a prize you did not enter for

> Congratulations! You have won a new phone. Send your one-time code to claim it.

**Warning signs:** Unexpected reward, request for a one-time code, too-good-to-be-true offer.

## Example 3: Payment change
**Subject:** New bank details for an invoice

> Please transfer the payment to these new details immediately. Do not call to confirm.

**Warning signs:** Payment redirection, urgency, discouraging independent verification.

## Discussion questions
1. What makes each message suspicious?
2. How could the request be verified safely?
3. Who should receive a report?
4. What would you do if you had already clicked or replied?

Never send these examples as deceptive messages without written authorization and a clear, privacy-conscious training plan.
