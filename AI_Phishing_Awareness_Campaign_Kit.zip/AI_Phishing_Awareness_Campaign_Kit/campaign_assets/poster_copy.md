# Poster Copy: PAUSE BEFORE YOU CLICK!

## THINK • CHECK • REPORT

Phishing messages may try to steal your password, money, or personal information.

**Look out for:**
- Urgent threats or pressure to act now
- Unexpected links or attachments
- Strange sender addresses
- Requests for passwords or one-time codes
- Unexpected payment or account-change requests

**Stay safe:**
1. Pause before acting.
2. Verify using a trusted, separate channel.
3. Report suspicious messages to your IT/help desk.

**Remember:** A logo can be copied. A familiar display name is not proof.

Campaign: AI Phishing Awareness Campaign Kit
