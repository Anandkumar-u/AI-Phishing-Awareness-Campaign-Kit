Subject: Join Our Phishing Awareness Campaign

Hello everyone,

Please take part in our AI Phishing Awareness Campaign. This short learning activity explains how to identify suspicious messages, verify unexpected requests, and report potential phishing safely.

During the campaign, you can:
- Learn six common warning signs.
- Review fictional examples.
- Complete a short knowledge quiz.
- Learn what to do if you click a suspicious link.

Always pause before clicking, never share passwords or one-time codes, and verify unusual requests through a trusted channel.

Thank you for helping create a safer digital community.

Cyber Safety Awareness Team
