# Five-Day Phishing Awareness Campaign

## Audience
Students, faculty, or staff in a school, college, or small organization.

## Objective
Improve recognition of phishing warning signs and encourage safe reporting. Set measurable targets before the campaign, such as improving average quiz scores by 20 percentage points.

## Day 1 — Launch
- Share the campaign poster and a short announcement.
- Explain phishing in plain language.
- Ask participants to complete the five-question baseline quiz.

## Day 2 — Spot the warning signs
- Share the six-point checklist: urgency, unexpected links, unusual sender, request for secrets, unexpected attachments, and odd context.
- Run a five-minute group discussion using the fictional examples.

## Day 3 — Verify before acting
- Demonstrate how to navigate independently to an official website.
- Explain verification through a known phone number or separate trusted channel.
- Remind participants never to share passwords or one-time codes.

## Day 4 — Report and recover
- Publish the institution's approved reporting contact or procedure.
- Explain what to do after a click or accidental disclosure.
- Reinforce that early reporting is better than hiding a mistake.

## Day 5 — Review
- Repeat the knowledge quiz.
- Compare aggregate pre/post results.
- Share three key lessons and invite anonymous feedback.

## Privacy and ethics
- Do not collect passwords, one-time codes, or sensitive personal data.
- Use aggregate quiz scores wherever possible.
- Tell participants the purpose of the campaign.
- Obtain required approval before any simulated phishing exercise.
- Do not shame individuals or publish individual scores.
