# AI Phishing Awareness Campaign Kit

A beginner-friendly cybersecurity awareness project for students, colleges, and small organizations. It teaches people how to recognize suspicious messages, verify requests, and report potential phishing safely.

## Project goals
- Explain common phishing warning signs.
- Provide safe, clearly fictional awareness examples.
- Offer an interactive knowledge quiz.
- Provide a reusable 5-day awareness campaign plan.
- Track campaign impact using privacy-conscious metrics.

## Features
- Responsive educational webpage.
- Interactive quiz with immediate feedback.
- Checklist for spotting phishing.
- Safe example messages that do not contain real links, attachments, credential collection, or impersonation of real organizations.
- Campaign schedule, poster copy, announcement text, and evaluation template.

## Run locally
1. Download or clone this repository.
2. Open `website/index.html` in a modern browser.
3. Take the quiz and explore the checklist.

No server, API key, login, or data collection is required.

## Repository structure
```text
AI_Phishing_Awareness_Campaign_Kit/
├── README.md
├── LICENSE
├── .gitignore
├── website/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── campaign_assets/
│   ├── sample_messages.md
│   ├── campaign_plan.md
│   ├── poster_copy.md
│   └── announcement_email.md
└── docs/
    ├── project_report.md
    └── evaluation_template.csv
```

## Safety and privacy
This is an awareness and education project, not a phishing tool. It does not send emails, collect passwords, track users, or create credential-harvesting pages. Examples use fictional names and reserved `.example` domains. Do not use real people's identities or send simulated phishing messages without authorization and appropriate safeguards.

## Suggested GitHub submission steps
1. Create a new public repository named `AI-Phishing-Awareness-Campaign-Kit`.
2. Upload all files in this folder, or push the folder using Git.
3. Add a screenshot of the webpage to the repository if desired.
4. In the repository description, use: `An educational phishing-awareness kit with a quiz, safe examples, and a ready-to-use awareness campaign plan.`
5. Add your name, institution, and date to the report if your instructor requires it.

## Possible future improvements
- Translate the learning material into local languages.
- Add an accessible, printable quiz.
- Run an opt-in pre/post awareness survey.
- Add a facilitator dashboard using anonymous aggregate results only.
