# Project Report: AI Phishing Awareness Campaign Kit

**Project category:** Cybersecurity awareness and education  
**Prepared by:** [Your Name]  
**Institution:** [Your College / School]  
**Date:** [Submission Date]

## 1. Abstract
Phishing is a social-engineering threat that attempts to trick people into sharing confidential information or performing unsafe actions. This project provides a simple, interactive learning kit to improve phishing awareness. It combines an educational webpage, a knowledge quiz, fictional message examples, campaign materials, and an evaluation plan. The site runs locally and does not collect personal information.

## 2. Problem statement
People may trust messages that appear urgent, familiar, or official. Limited awareness can lead to stolen account credentials, financial loss, and unauthorized access. A clear and accessible awareness resource can help users pause, verify, and report suspicious requests.

## 3. Objectives
- Explain phishing in accessible language.
- Teach common warning signs.
- Provide a short interactive quiz with feedback.
- Offer reusable materials for a five-day awareness campaign.
- Measure learning using aggregate pre/post quiz results while protecting privacy.

## 4. Proposed solution
The project is a static website built with HTML, CSS, and JavaScript. The homepage explains phishing and presents six warning signs. A five-question quiz checks understanding and explains each answer. Supporting Markdown documents provide fictional examples, a campaign schedule, poster copy, and an announcement email.

## 5. Tools and technologies
- HTML5: webpage structure
- CSS3: responsive visual design
- JavaScript: quiz interaction and scoring
- Markdown: campaign documentation
- CSV: evaluation template

No server, external API, login, or tracking is required.

## 6. Implementation
1. Open `website/index.html` in a browser.
2. Read the warning signs and safe-response steps.
3. Complete the quiz and review feedback.
4. Use the materials in `campaign_assets/` to run the campaign.
5. Record only aggregate results in the evaluation template.

## 7. Expected outcomes
- Better recognition of urgency, suspicious requests, and unexpected attachments.
- Improved understanding of independent verification.
- Increased confidence in reporting suspicious messages.
- Reusable awareness materials for educational settings.

## 8. Evaluation
Run the same quiz before and after the awareness campaign. Compare aggregate average scores and report the change in percentage points. Do not publish individual scores or collect passwords or other secrets. The CSV template contains example column headings, not real participant data.

## 9. Limitations
The quiz measures knowledge in a small set of scenarios; it does not prove that a person will identify every real phishing attempt. The examples are fictional and cannot represent every language, platform, or attack pattern. Results depend on participation and the quality of the campaign delivery.

## 10. Conclusion
The AI Phishing Awareness Campaign Kit offers a low-cost, privacy-conscious way to teach essential phishing safety habits. Its interactive webpage and ready-to-use campaign materials can be adapted for a classroom or campus awareness event. Future work could add multilingual content and an accessible printable handout.

## 11. Safety note
This project is intended for awareness education. It does not send phishing emails, create credential-harvesting pages, collect credentials, or track users. Any live simulation should require institutional approval, clear safeguards, and a defined reporting process.
